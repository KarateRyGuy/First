var img;

function preload(){
  img = loadImage("map.jpg")
}

function setup() {

  createCanvas(400,400, WEBGL);
}

function draw() {
  background(220);
  
  ambientLight(60);
  
  let locX = mouseX - width / 2;
  let locY = mouseY - height / 2;
  pointLight(255, 255, 255, locX, locY, 50);

  
  specularMaterial(250);
  shininess(50);


  fill('green');
  push();
  rotateZ(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
  box(70, 70, 70);
  pop();

  
  fill('blue');
  push();
  rotateZ(frameCount * -0.01);
  rotateX(frameCount * -0.01);
  rotateY(frameCount * -0.01);
  box(70, 70, 70);
  pop();
  
  push();
  translate(0, 0);
  texture(img);
  plane(img.width, img.height);
  pop();
}