//Allows me to have the parts of the poster to work.
var Shock
var Wave
var A = 'All Hail The Decepticons'
var B = "Long Live The Decepticons"
var firstFont;
var secondFont;

//This allows me to have external files to be losded into p5.js.
function preload(){
  Shock = loadImage('Shock.jpg')
  Wave = loadImage('Wave.jpg')
  firstFont = loadFont('Kings-Regular.ttf')
  secondFont = loadFont('Comforter-Regular.ttf')
}

function setup() {
  createCanvas(981,814)
}

//This is where I have everything work for the poster. I did want to have the main picture disaper but it wouldn't.
function draw() {
  
 if(mouseIsPressed){
   fill(0)
 }else{
       tint(128, 0, 128)
  loadImage('Shock.jpg', Shock => {
    image(Shock, 0, 0);
 });
 }
 
 if(mouseIsPressed){
   fill(0)
 } else{
  textFont(firstFont)
  textSize(45)
  fill('red')
  text(A,275,450,2000,2000)
 }
  
  //This is the second image I have that is hidden only if the mose is not pressed.
    if(mouseIsPressed){
    loadImage('Wave.jpg', Wave => {
    image(Wave, 260, 169);
    });
  } else{
    loadImage('Shock.jpg', Shock => {
    image(Shock, 0, 0);
    
  });
    
  }
  
  if(mouseIsPressed){
  textFont(secondFont)
  textSize(45)
  fill(255)
  text(B,275,400,2000,2000) 
} else{
  fill(0)
}
}