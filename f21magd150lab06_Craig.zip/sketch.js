

var circleX = 200;
var circleY = 200;
var a = 0
var c

function setup() { 
  createCanvas(400, 400);
  c=0
colorMode(HSB,360,100,100)
} 
//A couple of funtions because I am not creative in that way.
function draw() { 
  background(240);
  moveingCircle()
  rainbowCircle()
  rainbowBox()
}
//To start moving the Circle you need to click the Canvus.
function moveingCircle(){
  fill(0)
  ellipse(circleX, circleY, 50, 50);
  
  if (keyIsPressed) {
   if (keyCode == RIGHT_ARROW) {
    circleX +=5; 
   }  else if (keyCode == LEFT_ARROW) {
     circleX -= 5;
   } else if (keyCode == UP_ARROW) {
     circleY -= 5; 
   } else if (keyCode == DOWN_ARROW) {
     circleY +=5; 
   }
  }  
}

// I this is so that the second circle can move with the ASWD keys.
function rainbowCircle(){
  
}

//Something the fill the requirments for the project.
function rainbowBox(){
  
  fill(c,70,100)
  c+=1
    c=c%360

  rotate(a)
  rect(200,200,40,40)
  a = a + 0.01
}